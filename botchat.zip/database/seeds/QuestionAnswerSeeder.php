<?php

use Illuminate\Database\Seeder;
use App\Question;
use App\Answer;
class QuestionAnswerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Question::truncate();
        Answer::truncate();
        $questionAndAnswers = $this->getData();

        $questionAndAnswers->each(function ($question) {
            $createdQuestion = Question::create([
                'text' => $question['question'],
                'points' => $question['points'],
            ]);

            collect($question['answers'])->each(function ($answer) use ($createdQuestion) {
                Answer::create([
                    'question_id' => $createdQuestion->id,
                    'text' => $answer['text'],
                    'correct_one' => $answer['correct_one'],
                ]);
            });
        });
    }
    private function getData()
    {
        return collect([
            [
                'question' => "..... is place where you buy medicine.",
                'points' => '10',
                'answers' => [
                    ['text' => 'a bookstore', 'correct_one' => false],
                    ['text' => 'a restaurant', 'correct_one' => false],
                    ['text' => 'a pharmacy', 'correct_one' => true],
                    ['text' => 'a library', 'correct_one' => false],
                ],
            ],
            [
                'question' => "we usually use  .....  to cut paper.",
                'points' => '10',
                'answers' => [
                    ['text' => 'folders', 'correct_one' => false],
                    ['text' => 'rules', 'correct_one' => false],
                    ['text' => 'scissors', 'correct_one' => true],
                    ['text' => 'sharpeners', 'correct_one' => false],
                ],
            ],
            [
                'question' => "we are tired, we need to ..... .",
                'points' => '10',
                'answers' => [
                    ['text' => 'run', 'correct_one' => false],
                    ['text' => 'rest', 'correct_one' => true],
                    ['text' => 'swim', 'correct_one' => false],
                    ['text' => 'eat', 'correct_one' => false],
                ],
            ],
            [
                'question' => "i'll let you know ..... i've made my decision.",
                'points' => '10',
                'answers' => [
                    ['text' => 'as soon as', 'correct_one' => true],
                    ['text' => 'while', 'correct_one' => false],
                    ['text' => 'although', 'correct_one' => false],
                    ['text' => 'before', 'correct_one' => false],
                ],
            ],
            [
                'question' => "it's cold on that side of the room because the window doesn't ..... very well.",
                'points' => '10',
                'answers' => [
                    ['text' => 'swing', 'correct_one' => false],
                    ['text' => 'open', 'correct_one' => false],
                    ['text' => 'shut', 'correct_one' => true],
                    ['text' => 'look', 'correct_one' => false],
                ],
            ],
            [
                'question' => "he has so many houses. this house ..... him too.",
                'points' => '10',
                'answers' => [
                    ['text' => 'belongs to', 'correct_one' => true],
                    ['text' => 'owns', 'correct_one' => false],
                    ['text' => 'has', 'correct_one' => false],
                    ['text' => 'is next to', 'correct_one' => false],
                ],
            ],
            [
                'question' => "oh no, i've left my money at home. could you ..... me $5.",
                'points' => '10',
                'answers' => [
                    ['text' => 'borrow', 'correct_one' => false],
                    ['text' => 'lend', 'correct_one' => true],
                    ['text' => 'hide', 'correct_one' => false],
                    ['text' => 'show', 'correct_one' => false],
                ],
            ],
            [
                'question' => "the buses always arrive on time, They are ..... .",
                'points' => '10',
                'answers' => [
                    ['text' => 'usual', 'correct_one' => false],
                    ['text' => 'available', 'correct_one' => false],
                    ['text' => 'significant', 'correct_one' => false],
                    ['text' => 'punctual', 'correct_one' => true],
                ],
            ],
            [
                'question' => "the magazine is ..... every week.",
                'points' => '10',
                'answers' => [
                    ['text' => 'prescribed', 'correct_one' => false],
                    ['text' => 'made', 'correct_one' => false],
                    ['text' => 'published', 'correct_one' => true],
                    ['text' => 'done', 'correct_one' => false],
                ],
            ],
            [
                'question' => "there was a tall man standing in front of me so i couldn't ..... a thing.",
                'points' => '10',
                'answers' => [
                    ['text' => 'hear', 'correct_one' => false],
                    ['text' => 'see', 'correct_one' => true],
                    ['text' => 'eat', 'correct_one' => false],
                    ['text' => 'hold', 'correct_one' => false],
                ],
            ],
            [
                'question' => "my father#quote#s brother arc my ..... .",
                'points' => '10',
                'answers' => [
                    ['text' => 'uncles', 'correct_one' => true],
                    ['text' => 'nephews', 'correct_one' => false],
                    ['text' => 'cousins', 'correct_one' => false],
                    ['text' => 'aunts', 'correct_one' => false],
                ],
            ],
            [
                'question' => "i like a quite room, i have it when it is ..... .",
                'points' => '10',
                'answers' => [
                    ['text' => 'small', 'correct_one' => false],
                    ['text' => 'noisy', 'correct_one' => true],
                    ['text' => 'bright', 'correct_one' => false],
                    ['text' => 'slippery', 'correct_one' => false],
                ],
            ],
            [
                'question' => "i forgot to ..... my bed this morning.",
                'points' => '10',
                'answers' => [
                    ['text' => 'take', 'correct_one' => false],
                    ['text' => 'do', 'correct_one' => false],
                    ['text' => 'make', 'correct_one' => true],
                    ['text' => 'have', 'correct_one' => false],
                ],
            ],
            [
                'question' => "when i got home last night, i got ..... and went straight to bed.",
                'points' => '10',
                'answers' => [
                    ['text' => 'dressed', 'correct_one' => false],
                    ['text' => 'unusual', 'correct_one' => false],
                    ['text' => 'usual', 'correct_one' => false],
                    ['text' => 'undressed', 'correct_one' => true],
                ],
            ],
            [
                'question' => "there are 60 ..... in a minute.",
                'points' => '10',
                'answers' => [
                    ['text' => 'minutes', 'correct_one' => false],
                    ['text' => 'seconds', 'correct_one' => true],
                    ['text' => 'hours', 'correct_one' => false],
                    ['text' => 'times', 'correct_one' => false],
                ],
            ],
            [
                'question' => "i'm just going to put on a clean ..... of socks.",
                'points' => '10',
                'answers' => [
                    ['text' => 'lump', 'correct_one' => false],
                    ['text' => 'pair', 'correct_one' => true],
                    ['text' => 'bar', 'correct_one' => false],
                    ['text' => 'piece', 'correct_one' => false],
                ],
            ],            
        ]);
    }
}
