<?php
use BotMan\BotMan\BotMan;
use App\Http\Middleware\TypingMiddleware;
use App\Conversations\WelcomeConversation;
use App\Conversations\QuizConversation;
use App\Conversations\HighscoreConversation;
use App\Http\Controllers\BotManController;

$botman = resolve('botman');

$typingMiddleware = new TypingMiddleware();
$botman->middleware->sending($typingMiddleware);
$botman->hears('Hi', function ($bot) {
    $bot->reply('Hello!');
});
$botman->hears('/start', function (BotMan $bot) {
    $bot->startConversation(new WelcomeConversation());
})->stopsConversation();
$botman->hears('start', function (BotMan $bot) {
    $bot->startConversation(new WelcomeConversation());
})->stopsConversation();

// $botman->hears('start', function (BotMan $bot) {
//     $bot->startConversation(new QuizConversation());
// });
$botman->hears('/highscore', function (BotMan $bot) {
    $bot->startConversation(new HighscoreConversation());
})->stopsConversation();

$botman->hears('It just works', function($bot) {
    $bot->reply('Yep 🤘');
});
$botman->hears('about|ela', function (BotMan $bot) {
    $bot->reply('Ela-Bot is an english quiz bot 😊');
})->stopsConversation();